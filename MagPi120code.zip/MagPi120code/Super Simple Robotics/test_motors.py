# CamJam EduKit 3 - Robotics
# Motor Test Code

import time  # Import the Time library
from gpiozero import CamJamKitRobot  # Import the CamJam GPIO Zero Library

robot = CamJamKitRobot()

# Turn the motors on
robot.forward()

# Wait for 1 seconds
time.sleep(1)

# Turn the motors off
robot.stop()